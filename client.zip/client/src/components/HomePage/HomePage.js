import React from 'react';
import Container from './Container';


export default function HomePage() {
    return (
        <div>
            <Container/>
        </div>
    );
};