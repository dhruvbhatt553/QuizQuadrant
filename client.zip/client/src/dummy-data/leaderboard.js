const leaderboardData = [
    {
        "userId": 1,
        "name": "Dhruv",
        "marks": 56,
        "isPresent": true
    },
    {
        "userId": 2,
        "name": "Alice",
        "marks": 78,
        "isPresent": false
    },
    {
        "userId": 3,
        "name": "Bob",
        "marks": 84,
        "isPresent": true
    },
    {
        "userId": 4,
        "name": "Charlie",
        "marks": 65,
        "isPresent": true
    },
    {
        "userId": 5,
        "name": "Emma",
        "marks": 92,
        "isPresent": true
    },
    {
        "userId": 6,
        "name": "Frank",
        "marks": 71,
        "isPresent": true
    },
    {
        "userId": 7,
        "name": "Grace",
        "marks": 60,
        "isPresent": true
    },
    {
        "userId": 8,
        "name": "Henry",
        "marks": 79,
        "isPresent": true
    },
    {
        "userId": 9,
        "name": "Ivy",
        "marks": 88,
        "isPresent": true
    },
    {
        "userId": 10,
        "name": "Jack",
        "marks": 75,
        "isPresent": true
    }
];

export default leaderboardData;