package com.example.quizquadrant.service;

public class ImageTypes {

    public static String QUESTION = "a";
    public static String OPTION = "b";
    public static String SOLUTION = "c";
    public static String PRIVATE_QUESTION = "d";
    public static String PRIVATE_OPTION = "e";
    public static String PRIVATE_SOLUTION = "f";

}
