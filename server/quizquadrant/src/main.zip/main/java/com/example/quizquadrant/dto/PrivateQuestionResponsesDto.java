package com.example.quizquadrant.dto;

import java.util.List;

public record PrivateQuestionResponsesDto (
    List<Boolean> response
) {

}
