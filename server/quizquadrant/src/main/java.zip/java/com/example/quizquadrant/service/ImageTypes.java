package com.example.quizquadrant.service;

public class ImageTypes {

    public static String QUESTION = "Q";
    public static String OPTION = "O";
    public static String SOLUTION = "S";
    public static String PRIVATE_QUESTION = "q";
    public static String PRIVATE_OPTION = "o";
    public static String PRIVATE_SOLUTION = "s";

}
