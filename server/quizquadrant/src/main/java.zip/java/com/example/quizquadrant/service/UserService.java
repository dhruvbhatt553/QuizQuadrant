package com.example.quizquadrant.service;

import com.example.quizquadrant.dto.UserProfileDto;
import com.example.quizquadrant.model.Exam;
import com.example.quizquadrant.model.Result;
import com.example.quizquadrant.model.User;
import com.example.quizquadrant.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User getUserById(Long id) {
        Optional<User> userOptional = userRepository.findById(id);
        return userOptional.orElse(null);
    }

    public List<User> getUsersByEmailId(List<String> emailIds) {
        return userRepository.findUsersByEmail(emailIds);
    }





    public UserProfileDto getUserProfile(Long userId) {
//        TODO fetch userID from JWT token ...
        Optional<User> userOptional = userRepository.findById(userId);
        if(userOptional.isPresent()) {
            User user = userOptional.get();
            List<Long> examsCreated = new ArrayList<>();
            for(Exam exam: user.getExamsCreated()) {
                examsCreated.add(exam.getId());
            }
            List<Long> pastExams = new ArrayList<>();
            List<Long> ongoingExams = new ArrayList<>();
            List<Long> futureExams = new ArrayList<>();
            for(Result result: user.getExamResults()) {
                Exam exam = result.getExam();
                if(exam.getStartDateTime().isBefore(LocalDateTime.now())) {
                    if(exam.getStartDateTime().plusMinutes(exam.getDuration()).isBefore(LocalDateTime.now())) {
                        pastExams.add(exam.getId());
                    } else {
                        ongoingExams.add(exam.getId());
                    }
                } else {
                    futureExams.add(exam.getId());
                }
            }
            UserProfileDto userProfileDto = new UserProfileDto(
                    user.getName(),
                    user.getEmail(),
                    user.getType(),
                    examsCreated,
                    pastExams,
                    ongoingExams,
                    futureExams
            );
//            Exam title, totalMarks, result(marks)

            return userProfileDto;

        } else {
            return null;

        }
    }
}
